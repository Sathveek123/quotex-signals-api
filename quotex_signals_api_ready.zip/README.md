
# Quotex Signals API (Render-ready)

This is a FastAPI project that returns historical 1-minute candle data for:
- NZDUSD-OTC
- USDPHP-OTC
- USDJPY

## Quick start (local)
1. Create a `.env` file or set environment variable `TWELVED_API_KEY`.
2. Install deps:
```bash
pip install -r requirements.txt
```
3. Run:
```bash
uvicorn main:app --reload
```

## Deploy on Render
- Add `TWELVED_API_KEY` in Render Environment variables.
- Ensure Render service environment is **Python**.
- Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
