# main.py - Final Clean Version (Dhaka time, sorted, API-ready)
import os
from fastapi import FastAPI, HTTPException, Query
import requests
from datetime import datetime, timedelta
import pytz

app = FastAPI()

# Load API key from environment variable (set in Render, not hardcoded)
API_KEY = os.getenv("4e9ba925a839475a86f9112636ddd4a4")
if not API_KEY:
    raise Exception("TWELVED_API_KEY environment variable not set")

# Map friendly pair names to TwelveData format
PAIR_MAP = {
    "NZDUSD-OTC": "NZD/USD",
    "USDPHP-OTC": "USD/PHP",
    "USDJPY": "USD/JPY"
}

BASE_URL = "https://api.twelvedata.com/time_series"
DHAKA_TZ = pytz.timezone("Asia/Dhaka")

def to_dhaka(utc_str: str) -> str:
    """Convert UTC timestamp string to Dhaka timezone formatted string."""
    dt = datetime.strptime(utc_str, "%Y-%m-%d %H:%M:%S")
    dt = pytz.utc.localize(dt).astimezone(DHAKA_TZ)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

@app.get("/signals")
def get_signals(
    pair: str = Query(..., description="NZDUSD-OTC | USDPHP-OTC | USDJPY"),
    days: int = Query(1, ge=1, le=30)
):
    if pair not in PAIR_MAP:
        raise HTTPException(status_code=400, detail=f"Invalid pair. Must be one of: {', '.join(PAIR_MAP.keys())}")

    symbol = PAIR_MAP[pair]
    cutoff = datetime.utcnow() - timedelta(days=days)

    params = {
        "symbol": symbol,
        "interval": "1min",
        "apikey": API_KEY,
        "outputsize": 5000
    }

    try:
        r = requests.get(BASE_URL, params=params, timeout=30)
        r.raise_for_status()
    except requests.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Error fetching data: {str(e)}")

    data = r.json()
    values = data.get("values", [])
    if not values:
        raise HTTPException(status_code=404, detail="No data returned from API")

    result = []
    for item in values:
        ts = datetime.strptime(item["datetime"], "%Y-%m-%d %H:%M:%S")
        if ts >= cutoff:
            result.append({
                "timestamp": to_dhaka(item["datetime"]),
                "pair": pair,
                "open": float(item["open"]),
                "high": float(item["high"]),
                "low": float(item["low"]),
                "close": float(item["close"])
            })

    # Sort in ascending order (oldest first)
    result.sort(key=lambda x: x["timestamp"])

    return {
        "pair": pair,
        "timezone": "Asia/Dhaka",
        "count": len(result),
        "candles": result
    }
